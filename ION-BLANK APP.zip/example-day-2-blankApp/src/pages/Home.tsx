import {
  IonButton,
  IonContent,
  IonHeader,
  IonImg,
  IonPage,
  IonTitle,
  IonToolbar,
} from "@ionic/react";
import "./Home.css";
import { Camera, CameraResultType } from "@capacitor/camera";
import { useState } from "react";

const Home: React.FC = () => {
  const [image, setImage] = useState<any>("");

  const takePicture = async () => {
    // promises...
    try {
      const cameraResult = await Camera.getPhoto({
        quality: 90,
        // allowEditing: true,
        resultType: CameraResultType.Uri,
      });

      setImage(cameraResult.webPath);

      // Can be set to the src of an image now
      //imageElement.src = imageUrl;
      console.log(image);
    } catch (e) {
      console.log(e);
    }
  };

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Blank</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent fullscreen className="ion-padding">
        <div>IN BASIC APP</div>
        <IonButton onClick={() => takePicture()}>CLICK ME</IonButton>
        <IonImg src={image}></IonImg>
        <IonButton routerLink={"/about"}>GO ABOUT</IonButton>
      </IonContent>
    </IonPage>
  );
};

export default Home;
